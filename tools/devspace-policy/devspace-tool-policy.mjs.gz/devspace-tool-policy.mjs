#!/usr/bin/env node
/**
 * DevSpace MCP tool-description policy patch, multi-host edition.
 *
 * Changes ONLY user-facing text within DevSpace dist/server.js:
 *   - serverInstructions() instructions;
 *   - the MCP bash tool description.
 * Does NOT change command executors, OAuth, permissions, authorization, or
 * the ChatGPT platform safety/confirmation checks.
 *
 * Commands: node devspace-tool-policy.mjs status|check|apply|rollback|watchdog
 * Supports Debian/Linux with systemd and Windows (admin PowerShell).
 * Deliberately fails closed when upstream strings or package shape differ.
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import net from 'node:net';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

export const POLICY_TAG = 'DevSpace authorized maintenance policy v2';
const PACKAGE_NAME = '@waishnav/devspace';
const SERVICE = 'devspace.service';
const STATE_NAME = 'devspace-tool-policy';
const THIS_SCRIPT = fileURLToPath(import.meta.url);
const DEFAULT_PORT = 7676;
const PAIRS = [
  {
    name: 'serverInstructions intro',
    original: 'Use DevSpace for coding work.',
    replacement: `Use DevSpace for coding, testing, deployment and server maintenance explicitly authorized by the user. ${POLICY_TAG}.`,
  },
  {
    name: 'serverInstructions bash guidance',
    original: 'for tests, builds, git inspection, package scripts, and commands that are better executed by the shell. Do not create or modify files with ${toolNames.shell}; avoid shell redirection, heredocs, tee, sed -i, perl -i, node/python/ruby scripts, or any command whose purpose is to write project files.',
    replacement: 'for tests, builds, Git operations, package installation, deployment and updates of services and containers, configuration, diagnostics, and other user-authorized local administration. Prefer DevSpace edit/write tools for normal project-source changes; shell-based edits may be used for authorized system configuration, deployment workflows, and system-owned files. Verify the effects, preserve rollback paths, and seek confirmation for high-impact actions. All existing tool and platform safety checks remain in force.',
  },
  {
    name: 'bash description allowed work',
    original: 'Use only for tests, builds, git inspection, package scripts, search, file discovery, and directory inspection.',
    replacement: 'Use for user-authorized development, testing, builds, Git operations, dependency installation, service/container deployment, system maintenance, diagnostics, file discovery and inspection.',
  },
  {
    name: 'bash description file editing',
    original: 'Do not use bash to create or modify files. Do not use shell redirection, heredocs, tee, sed -i, perl -i, node/python/ruby scripts, or generated scripts to write project files; use edit for targeted changes and write for new files or full rewrites.',
    replacement: 'Prefer the read/edit/write tools for ordinary project file changes. Shell-based configuration edits are permitted when necessary for a user-authorized deployment, service maintenance or a system-owned file. Inspect affected resources, keep backups, test results and request confirmation for high-risk changes.',
  },
];

function digest(content) {return crypto.createHash('sha256').update(content).digest('hex');}
function run(file, args, options = {}) {
  try {return spawnSync(file, args, {encoding:'utf8',timeout:12000,maxBuffer:8192,windowsHide:true,...options});}
  catch(e){return {status:127,stdout:'',stderr:e?.message||'exec failed',error:e};}
}
function safeMessage(e){return String(e?.message || e).slice(0,350);}
function fail(message){throw new Error(message);}
function one(text, part, name) {
  const n=text.split(part).length-1;
  if(n!==1) fail(`Incompatible DevSpace source: expected exactly one ${name}; got ${n}. No change made.`);
}
export function transformSource(before) {
  if(typeof before!=='string')fail('Source must be UTF-8 text');
  if(before.includes(POLICY_TAG))return {source:before, already:true, changes:[]};
  if(!before.includes('function serverInstructions(config)') ||
     !before.includes('registerAppTool(server, toolNames.shell,')) {
    fail('Unexpected DevSpace MCP registration layout. No change made.');
  }
  if(before.includes('DevSpace authorized deployment policy v1'))
    fail('An older policy patch is present. Roll it back before applying v2.');
  let result=before;
  for(const p of PAIRS){one(result,p.original,p.name);result=result.replace(p.original,p.replacement);}
  if(result.split(POLICY_TAG).length!==2)fail('Policy marker appears more than once');
  return {source:result,already:false,changes:PAIRS.map(x=>x.name)};
}

function packageRoots() {
  const candidates=[];
  const add=x=>{if(x && !candidates.includes(x)) candidates.push(x);};
  if(process.env.DEVSPACE_PACKAGE_DIR)add(path.resolve(process.env.DEVSPACE_PACKAGE_DIR));
  const npm=process.platform==='win32'?'npm.cmd':'npm';
  const npmRun=run(npm,['root','-g'],{timeout:8000,shell:process.platform==='win32'});
  if(npmRun.status===0){
    const lines=(npmRun.stdout||'').trim().split(/\r?\n/);
    const root=lines.at(-1)?.trim();
    if(root)add(path.join(root,'@waishnav','devspace'));
  }
  const parts=(process.env.PATH || '').split(path.delimiter);
  for(const part of parts){
    if(!part)continue;
    const binary=path.join(part,process.platform==='win32'?'devspace.cmd':'devspace');
    if(!fs.existsSync(binary))continue;
    if(process.platform==='win32')add(path.join(part,'node_modules','@waishnav','devspace'));
    else{
      try {
        const real=fs.realpathSync(binary);
        add(path.resolve(path.dirname(real),'..'));
      }catch{}
    }
  }
  add('/usr/lib/node_modules/@waishnav/devspace');
  add('/usr/local/lib/node_modules/@waishnav/devspace');
  add('/opt/node_modules/@waishnav/devspace');
  if(process.platform==='win32'){
    if(process.env.APPDATA)add(path.join(process.env.APPDATA,'npm','node_modules','@waishnav','devspace'));
    if(process.env.ProgramFiles)add(path.join(process.env.ProgramFiles,'nodejs','node_modules','@waishnav','devspace'));
  }
  return candidates;
}
function findPackage() {
  for(const root of packageRoots()){
    const meta=path.join(root,'package.json');
    const target=path.join(root,'dist','server.js');
    if(!fs.existsSync(meta)||!fs.existsSync(target))continue;
    let p;try{p=JSON.parse(fs.readFileSync(meta,'utf8'));}catch{continue;}
    if(p.name===PACKAGE_NAME)return {root,target,version:p.version};
  }
  fail('Could not locate installed @waishnav/devspace. Use DEVSPACE_PACKAGE_DIR=/path/to/package if it is installed in a custom location.');
}
function stateDir() {
  // Write-owned by local system admin, independent of npm upgrades.
  if(process.env.DEVSPACE_TOOL_POLICY_STATE_DIR)return path.resolve(process.env.DEVSPACE_TOOL_POLICY_STATE_DIR);
  if(process.platform==='win32')return path.join(process.env.ProgramData || 'C:\\ProgramData','DevSpaceToolPolicy');
  return '/var/backups/devspace-tool-policy';
}
const paths=()=>{const state=stateDir();return {state,backup:path.join(state,'server.js.before'),manifest:path.join(state,'manifest.json'),localCopy:path.join(state,'devspace-tool-policy.mjs')};};
function current() {
  const pkg=findPackage();
  const data=fs.readFileSync(pkg.target);
  return {...pkg,text:data.toString('utf8'),hash:digest(data)};
}
function savedManifest() {
  try{return JSON.parse(fs.readFileSync(paths().manifest,'utf8'));}catch{return null;}
}
function serviceInfo() {
  if(process.platform==='linux'){
    const got=run('/usr/bin/systemctl',['is-active',SERVICE],{timeout:4000});
    return {manager:'systemd',unit:SERVICE,active:got.status===0 && got.stdout.trim()==='active'};
  }
  if(process.platform==='win32'){
    const got=run('sc.exe',['query','devspace'],{timeout:4500});
    const exists=got.status===0;
    return {manager:'Windows Service Control Manager',unit:'devspace',exists,
      active:exists && /STATE\s*:\s*4\s+RUNNING/i.test(got.stdout)};
  }
  return {manager:'unknown',active:false};
}
function ownerCheck() {
  if(process.platform!=='win32' && process.getuid?.()!==0) fail('Root privileges required: run using sudo node ... apply/rollback');
  if(process.platform==='win32'){
    const probe=run('fltmc.exe',[],{timeout:3000});
    if(probe.status!==0)fail('Run PowerShell as Administrator to modify the global DevSpace package');
  }
}
function stableMetadata(c){
  const m=savedManifest();
  return {platform:process.platform,version:c.version,serverFile:c.target,
    sourceSHA256:c.hash,policyInstalled:c.text.includes(POLICY_TAG),
    operatorHookPreserved:c.text.includes('DEVSPACE_OPERATOR_HOOK_V1'),
    backupPresent:fs.existsSync(paths().backup),
    rollbackAvailable:Boolean(m && m.afterSha256===c.hash && fs.existsSync(paths().backup)),
    service:serviceInfo(),oauthChanged:false,executorChanged:false};
}
function safeCreateDir(dir){fs.mkdirSync(dir,{recursive:true,mode:0o700});if(process.platform!=='win32')fs.chmodSync(dir,0o700);}
function atomicWrite(dest,bytes,mode=0o644,checkJs=true){
  const tmp=dest+'.policy-stage-'+process.pid+'-'+crypto.randomBytes(5).toString('hex')+'.mjs';
  try{
    fs.writeFileSync(tmp,bytes,{flag:'wx',mode});
    if(process.platform!=='win32')fs.chmodSync(tmp,mode);
    if(checkJs){const r=run(process.execPath,['--check',tmp],{timeout:16000});if(r.status!==0)fail('JavaScript syntax check failed: '+(r.stderr||'').slice(0,300));}
    fs.renameSync(tmp,dest);
  }finally{try{if(fs.existsSync(tmp))fs.unlinkSync(tmp);}catch{}}
}
function scheduleSystemd(unitPrefix,seconds,command,args){
  const bin=fs.existsSync('/usr/bin/systemd-run')?'/usr/bin/systemd-run':'systemd-run';
  const r=run(bin,['--quiet','--unit',unitPrefix+'-'+process.pid,'--on-active='+seconds+'s',command,...args],{timeout:9000});
  return {ok:r.status===0,error:r.status===0?undefined:(r.stderr||r.stdout||'schedule failed').slice(0,130)};
}
function restartDeferred(){
  const s=serviceInfo();
  if(process.platform==='linux' && s.active){
    const r=scheduleSystemd('devspace-policy-restart',5,'/usr/bin/systemctl',['restart',SERVICE]);
    return {scheduled:r.ok,method:'systemd-run',error:r.error};
  }
  if(process.platform==='win32' && s.exists){
    const r=run('sc.exe',['stop','devspace'],{timeout:10000});
    const start=run('sc.exe',['start','devspace'],{timeout:10000});
    return {scheduled:false,method:'sc.exe',restartAttempted:true,stopped:r.status===0,started:start.status===0};
  }
  return {scheduled:false,method:'manual',note:'DevSpace is not managed by a recognized service; restart its process/session manually.'};
}
function scheduleWatchdog(){
  if(process.platform!=='linux' || !serviceInfo().active)return {scheduled:false};
  const r=scheduleSystemd('devspace-policy-watchdog',35,process.execPath,[paths().localCopy,'watchdog']);
  return {scheduled:r.ok,error:r.error};
}
function getPort(){
  const user=run('/usr/bin/systemctl',['show',SERVICE,'--property=User','--value'],{timeout:4000});
  if(user.status!==0)return DEFAULT_PORT;
  const name=user.stdout.trim();
  if(!name)return DEFAULT_PORT;
  const entry=run('getent',['passwd',name],{timeout:4000});
  if(entry.status!==0)return DEFAULT_PORT;
  const home=entry.stdout.trim().split(':')[5];
  if(!home)return DEFAULT_PORT;
  const config=path.join(home,'.devspace','config.json');
  try{const port=JSON.parse(fs.readFileSync(config,'utf8')).port;return Number.isInteger(port)&&port>0&&port<65536?port:DEFAULT_PORT;}catch{return DEFAULT_PORT;}
}
function canConnect(port){
  return new Promise(resolve=>{
    const s=net.connect({host:'127.0.0.1',port});
    s.once('connect',()=>{s.destroy();resolve(true)});
    s.once('error',()=>resolve(false));
    s.setTimeout(1600,()=>{s.destroy();resolve(false)});
  });
}
async function watchdog(){
  if(process.platform!=='linux')return;
  const m=savedManifest();if(!m)return;
  let healthy=false;
  for(let i=0;i<8;i++){
    const s=serviceInfo();if(s.active && await canConnect(getPort())){healthy=true;break;}
    await new Promise(r=>setTimeout(r,2000));
  }
  if(healthy){console.log(JSON.stringify({ok:true,watchdog:'healthy'}));return;}
  const c=current();
  if(c.hash!==m.afterSha256)fail('Watchdog: source changed since policy installation; cannot auto-restore');
  const before=fs.readFileSync(paths().backup);
  if(digest(before)!==m.beforeSha256)fail('Watchdog: backup digest mismatch');
  atomicWrite(c.target,before,fs.statSync(c.target).mode & 0o777);
  const r=run('/usr/bin/systemctl',['restart',SERVICE],{timeout:18000});
  console.log(JSON.stringify({ok:r.status===0,watchdog:'restored_original',restartStatus:r.status}));
}
function apply(){
  ownerCheck();const c=current();
  if(c.text.includes(POLICY_TAG)){
    const m=savedManifest();
    if(!m || c.hash!==m.afterSha256)fail('Policy marker found but tracked manifest is missing or incompatible; not overwriting');
    console.log(JSON.stringify({ok:true,alreadyInstalled:true,...stableMetadata(c)}));return;
  }
  if(!/^1\./.test(c.version))fail(`DevSpace ${c.version} is not in the 1.x series; refusing patch`);
  const update=transformSource(c.text);
  if(update.already)fail('Untracked existing policy found');
  const newText=update.source;
  const newSHA=digest(Buffer.from(newText));
  const {state,backup,manifest,localCopy}=paths();
  const oldState=savedManifest();
  const existingBackup=fs.existsSync(backup);
  if(existingBackup || oldState) {
    if(!existingBackup || !oldState || oldState.target!==c.target ||
       oldState.beforeSha256!==c.hash || digest(fs.readFileSync(backup))!==c.hash)
      fail('Existing policy state is incompatible with current source; refusing overwrite');
    // Allows an idempotent re-install after our own verified rollback.
  }
  safeCreateDir(state);
  if(!existingBackup){
    fs.writeFileSync(backup,Buffer.from(c.text),{flag:'wx',mode:0o600});
    if(process.platform!=='win32')fs.chmodSync(backup,0o600);
  }
  const info={version:c.version,target:c.target,beforeSha256:c.hash,afterSha256:newSHA,
    changed:update.changes,operatorHookPreserved:c.text.includes('DEVSPACE_OPERATOR_HOOK_V1'),
    installedAt:new Date().toISOString(),scriptSha256:digest(fs.readFileSync(THIS_SCRIPT))};
  atomicWrite(manifest,Buffer.from(JSON.stringify(info,null,2)+'\n'),0o600,false);
  if(process.platform!=='win32')fs.chmodSync(manifest,0o600);
  fs.copyFileSync(THIS_SCRIPT,localCopy);
  if(process.platform!=='win32')fs.chmodSync(localCopy,0o600);
  // Source may have been changed by another package-management process since preflight.
  if(digest(fs.readFileSync(c.target))!==c.hash)fail('DevSpace was changed during preflight; aborting before replacement');
  atomicWrite(c.target,Buffer.from(newText),fs.statSync(c.target).mode & 0o777);
  if(digest(fs.readFileSync(c.target))!==newSHA)fail('Post-write integrity mismatch');
  const restart=restartDeferred();
  const watch=restart.scheduled?scheduleWatchdog():{scheduled:false};
  console.log(JSON.stringify({ok:true,applied:true,version:c.version,afterSHA256:newSHA,
    changed:update.changes,authAndExecutorUnchanged:true,existingOperatorPreserved:info.operatorHookPreserved,
    restart,watchdog:watch,backup,refreshChatGPTConnectorTools:true}));
}
function rollback(){
  ownerCheck();const c=current();const m=savedManifest();
  if(!m||!fs.existsSync(paths().backup))fail('Rollback manifest/backup missing');
  if(m.target!==c.target||m.afterSha256!==c.hash)fail('Installed source changed since patch; cannot overwrite unrelated changes');
  const before=fs.readFileSync(paths().backup);
  if(digest(before)!==m.beforeSha256)fail('Original source backup integrity check failed');
  atomicWrite(c.target,before,fs.statSync(c.target).mode & 0o777);
  const restart=restartDeferred();
  // Retain backup and manifest for an audit trail. Reinstallation must be explicit.
  console.log(JSON.stringify({ok:true,rolledBack:true,restoredSHA256:m.beforeSha256,restart,authAndExecutorUnchanged:true}));
}
function status(){const c=current();console.log(JSON.stringify({ok:true,...stableMetadata(c)},null,2));}
function check(){const c=current();const r=transformSource(c.text);const newSha=digest(Buffer.from(r.source));
 console.log(JSON.stringify({ok:true,version:c.version,target:c.target,
  compatible:true,alreadyInstalled:r.already,previewSHA256:newSha,
  changes:r.changes,existingOperatorPreserved:c.text.includes('DEVSPACE_OPERATOR_HOOK_V1'),
  service:serviceInfo(),changedFiles:0},null,2));}

const cliPath=process.argv[1]&&path.resolve(process.argv[1]);
if(cliPath && (process.platform==='win32' ? cliPath.toLowerCase()===THIS_SCRIPT.toLowerCase() : cliPath===THIS_SCRIPT)){
  try{
    const action=process.argv[2]||'status';
    switch(action){
      case 'status':status();break;
      case 'check':check();break;
      case 'apply':apply();break;
      case 'rollback':rollback();break;
      case 'watchdog':await watchdog();break;
      default:fail('Usage: node devspace-tool-policy.mjs [status|check|apply|rollback]');
    }
  }catch(e){console.error('DEVSPACE_POLICY_ERROR:',safeMessage(e));process.exitCode=1;}
}

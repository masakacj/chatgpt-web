import { createRequire } from 'node:module';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

// This integration is loaded by the already authenticated DevSpace MCP server.
// It does not open another listener or expose arbitrary shell execution.
const require = createRequire('/usr/lib/node_modules/@waishnav/devspace/package.json');
const z = require('zod/v4');
const execute = promisify(execFile);
const BROKER = '/usr/local/sbin/devspace-adminctl';
const allowedName = z.string().regex(/^[a-z][a-z0-9-]{1,62}$/);

async function invoke(operation, payload) {
  try {
    const { stdout } = await execute('/usr/bin/sudo', ['-n', BROKER, operation, JSON.stringify(payload)], {
      timeout: operation === 'deploy' ? 150000 : 18000,
      maxBuffer: 48 * 1024,
      env: { PATH: '/usr/sbin:/usr/bin:/sbin:/bin' },
      encoding: 'utf8',
    });
    const parsed = JSON.parse(stdout.trim());
    return { content: [{ type: 'text', text: JSON.stringify(parsed) }], structuredContent: parsed };
  } catch (e) {
    // Never include argv, input, environment, stderr or private file contents.
    const error = { ok: false, error: 'ADMIN_OPERATION_FAILED', operation,
      exitCode: Number.isInteger(e.code) ? e.code : null };
    return { isError: true, content: [{ type: 'text', text: JSON.stringify(error) }] };
  }
}

export function registerAdminMcpTools(server) {
  server.registerTool('admin_list', {
    title: 'List approved local service deployments',
    description: 'Read-only: display the root-owned allowlist of services and deployment recipes for this host. No credentials.',
    inputSchema: {},
    annotations: { readOnlyHint: true, destructiveHint: false },
  }, async () => invoke('list', {}));

  server.registerTool('admin_service', {
    title: 'Manage approved systemd service',
    description: 'Manage a preapproved systemd service by its registry name. Only named units and allowed actions are permitted. STOP/DISABLE require an exact confirmation string. Never executes arbitrary shell.',
    inputSchema: {
      service: allowedName,
      action: z.enum(['status', 'start', 'restart', 'stop', 'disable', 'enable']),
      confirmation: z.string().max(96).optional(),
    },
    annotations: { readOnlyHint: false, destructiveHint: true, openWorldHint: false },
  }, async args => invoke('service', args));

  server.registerTool('admin_logs', {
    title: 'Read approved systemd unit journal',
    description: 'Read bounded service logs for a registered unit. Credentials are redacted; no arbitrary journal query.',
    inputSchema: {
      service: allowedName,
      lines: z.number().int().min(10).max(120).default(35),
    },
    annotations: { readOnlyHint: true, destructiveHint: false },
  }, async args => invoke('logs', args));

  server.registerTool('admin_deploy', {
    title: 'Execute an approved, version-pinned deployment recipe',
    description: 'Run one root-owned registered deployment script. Registry pins script SHA-256. No script content, URL, path, arbitrary commands or credentials are accepted from MCP. Requires a clear user-requested deployment.',
    inputSchema: {
      deployment: allowedName,
      confirmation: z.literal('EXECUTE_APPROVED_DEPLOYMENT'),
    },
    annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: false, openWorldHint: false },
  }, async args => invoke('deploy', args));
}

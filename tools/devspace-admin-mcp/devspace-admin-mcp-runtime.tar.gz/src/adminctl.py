#!/usr/bin/env python3
"""Root-owned DevSpace admin broker. Strict JSON and name allowlist; no shell."""
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import syslog
from pathlib import Path

REGISTRY = Path('/etc/devspace-admin-mcp/profiles.json')
JOB_ROOT = Path('/opt/devspace-admin-mcp/jobs')
NAME = re.compile(r'^[a-z][a-z0-9-]{1,62}$')
UNIT = re.compile(r'^[a-zA-Z0-9_.@-]{3,110}\.service$')
MAX_OUTPUT = 13000


def safe_owner(path):
    st = path.lstat()
    return st.st_uid == 0 and not st.st_mode & (stat.S_IWGRP | stat.S_IWOTH) and not stat.S_ISLNK(st.st_mode)


def registry():
    if not safe_owner(REGISTRY):
        raise ValueError('Registry must be a root-owned, non-writable-by-others regular file')
    data = json.loads(REGISTRY.read_text())
    if data.get('schema') != 1 or not isinstance(data.get('services'), dict) or not isinstance(data.get('deployments'), dict):
        raise ValueError('Unexpected registry schema')
    return data


def run(argv, timeout=15):
    p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=False,
                       env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','LANG':'C.UTF-8'})
    return p.returncode, p.stdout[:MAX_OUTPUT], p.stderr[:1500]


def secret_redact(value):
    value = re.sub(r'(?i)(authorization\s*[:=]\s*)(\S+)', r'\1[REDACTED]', value)
    value = re.sub(r'(?i)(password|passwd|secret|api[_-]?key|access[_-]?token)(\s*[:=]\s*)([^\s,;]+)',
                   r'\1\2[REDACTED]', value)
    value = re.sub(r'(?i)(https?://)[^/@\s]+:[^/@\s]+@', r'\1[REDACTED]@', value)
    return value


def service_data(data, name):
    if not NAME.fullmatch(name):
        raise ValueError('Invalid service name')
    entry = data['services'].get(name)
    if not isinstance(entry, dict):
        raise ValueError('Service not on root-owned allowlist')
    unit = entry.get('unit')
    if not isinstance(unit, str) or not UNIT.fullmatch(unit):
        raise ValueError('Invalid fixed systemd unit')
    return entry, unit


def action_service(data, args):
    entry, unit = service_data(data, args['service'])
    action = args['action']
    permitted = entry.get('actions', ['status'])
    if action not in ('status','start','restart','stop','disable','enable') or action not in permitted:
        raise ValueError('Action not permitted for this service')
    if action in ('stop','disable') and args.get('confirmation') != f'{action.upper()}:{args["service"]}':
        raise ValueError('Exact stop/disable confirmation required')
    if action == 'status':
        code, out, _ = run(['/usr/bin/systemctl','show',unit,'-p','LoadState','-p','ActiveState','-p','SubState','-p','UnitFileState','--no-pager'])
        if code != 0: raise RuntimeError('Unable to read systemd status')
        return {'ok': True,'service':args['service'],'unit':unit,'status':dict(line.split('=',1) for line in out.strip().splitlines() if '=' in line)}
    code, _, _ = run(['/usr/bin/systemctl',action,unit],timeout=45)
    if code != 0: raise RuntimeError(f'systemd {action} returned nonzero')
    _, out, _ = run(['/usr/bin/systemctl','is-active',unit])
    return {'ok':True,'service':args['service'],'action':action,'active':out.strip()}


def action_logs(data, args):
    _, unit = service_data(data, args['service'])
    lines = args.get('lines',35)
    if not isinstance(lines, int) or not 10 <= lines <= 120: raise ValueError('Invalid log limit')
    code, out, _ = run(['/usr/bin/journalctl','--no-pager','--output','short-iso',
                        '-u',unit,'--lines',str(lines)],timeout=12)
    if code != 0: raise RuntimeError('Could not read service journal')
    return {'ok':True,'service':args['service'],'lines':secret_redact(out)[-MAX_OUTPUT:]}


def action_deploy(data,args):
    name = args.get('deployment')
    if not isinstance(name,str) or not NAME.fullmatch(name): raise ValueError('Invalid deployment name')
    if args.get('confirmation') != 'EXECUTE_APPROVED_DEPLOYMENT': raise ValueError('Confirmation required')
    entry = data['deployments'].get(name)
    if not isinstance(entry,dict): raise ValueError('Deployment not registered')
    job = (JOB_ROOT / (name+'.py')).resolve(strict=True)
    if not job.is_relative_to(JOB_ROOT) or not safe_owner(job):
        raise ValueError('Job path/ownership verification failed')
    digest = hashlib.sha256(job.read_bytes()).hexdigest()
    if entry.get('sha256') != digest: raise ValueError('Job checksum mismatch; local admin must reapprove')
    timeout = entry.get('timeoutSeconds',45)
    if not isinstance(timeout,int) or not 5 <= timeout <= 120: raise ValueError('Invalid timeout')
    code,out,err = run(['/usr/bin/python3','-I','-B',str(job)],timeout=timeout)
    if code != 0:
        raise RuntimeError(f'Approved deployment exited nonzero ({code}); inspect local journal')
    try:
        result=json.loads(out)
    except ValueError as e:
        raise RuntimeError('Job did not return valid JSON') from e
    if not isinstance(result,dict) or result.get('ok') is not True:
        raise RuntimeError('Deployment did not acknowledge success')
    # Return only a known, nonsecret subset. Never forward freeform job output.
    return {'ok': True,'deployment':name,'result':{k:result[k] for k in ('status','app','primary','backup','unchanged') if k in result}}


def main():
    if os.geteuid() != 0: raise PermissionError('Requires root via the pinned sudo command')
    if len(sys.argv) != 3 or sys.argv[1] not in ('list','service','logs','deploy'):
        raise ValueError('Expected a fixed operation and JSON argument')
    operation = sys.argv[1]
    payload = json.loads(sys.argv[2])
    if not isinstance(payload,dict): raise ValueError('Expected an object')
    data = registry()
    syslog.openlog('devspace-admin-mcp', syslog.LOG_PID, syslog.LOG_AUTHPRIV)
    # No credentials or JSON payload in system journal.
    try:
        if operation == 'list':
            result={'ok':True,'services':{k:v.get('actions',['status']) for k,v in data['services'].items()},
                    'deployments':sorted(data['deployments'].keys())}
        elif operation == 'service':result=action_service(data,payload)
        elif operation == 'logs':result=action_logs(data,payload)
        else:result=action_deploy(data,payload)
        syslog.syslog(syslog.LOG_INFO,f'operation={operation} succeeded')
        print(json.dumps(result,ensure_ascii=False))
    except Exception:
        syslog.syslog(syslog.LOG_WARNING,f'operation={operation} failed')
        raise


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        # Never print exception detail: it may embed an internal path or secret.
        print(json.dumps({'ok':False,'error':'ADMIN_OPERATION_REJECTED','errorType':type(exc).__name__}))
        raise SystemExit(1)

#!/usr/bin/env python3
"""Approve-only app-scoped import. Secrets never go through MCP messages/logs."""
import json
import os
import stat
import subprocess
from pathlib import Path

OLD_CONFIG = Path('/var/lib/personal-config-service/config.json')
STAGED = Path('/home/devspace/.config/optimizer-officeserver-provision-v2-20261117.json')


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def main():
    require(os.geteuid() == 0, 'must run root')
    require(STAGED.is_file(), 'staged office server credentials missing')
    require(STAGED.stat().st_mode & 0o077 == 0, 'staging permissions not private')
    before = json.loads(OLD_CONFIG.read_text())
    apps = before.get('apps', {})
    legacy = apps.get('optimizer', {})
    require('optimizer-v2' not in apps, 'optimizer-v2 already installed')
    office = legacy.get('plan', {}).get('office', {})
    require(office.get('host') == 'gosto.781751.xyz' and office.get('port') == 18444 and
            office.get('username') == 'optimizer-office' and
            legacy.get('plan',{}).get('denyDirect') is True and
            isinstance(legacy.get('officePassword'),str) and len(legacy['officePassword']) >= 20,
            'unexpected existing Office backup')
    stage = json.loads(STAGED.read_text())
    require(stage.get('kind') == 'optimizer-office-server-v2' and
            stage.get('server') == 'gostos.781751.xyz' and
            stage.get('port') == 18445 and stage.get('username') == 'optimizer-os' and
            isinstance(stage.get('password'),str) and len(stage['password']) >= 30,
            'unexpected OfficeServer credential metadata')
    config = {'plan': {'mode':'officeServer',
                       'officeServer':{'host':'gostos.781751.xyz','port':18445,'username':'optimizer-os'},
                       'office':office, 'backupEnabled':True, 'denyDirect':True},
              'officeServerPassword':stage['password'],
              'officePassword':legacy['officePassword']}
    # This is the existing app-scoped atomic config admin. No generic file writer.
    p = subprocess.run(['/usr/bin/node','/home/devspace/config-service/admin.mjs','set','optimizer-v2'],
                       input=json.dumps(config),text=True,capture_output=True,timeout=25)
    require(p.returncode == 0, 'atomic private config writer failed')
    require(json.loads(p.stdout) == {'ok':True,'updatedApp':'optimizer-v2'}, 'writer acknowledgement mismatch')
    after = json.loads(OLD_CONFIG.read_text()).get('apps',{})
    require(set(after) == set(apps) | {'optimizer-v2'} and
            all(after[k] == v for k,v in apps.items()) and after['optimizer-v2'] == config,
            'read-back mismatch: inspect private configuration')
    # Keep staged secret (0600) for local operator-controlled disaster recovery.
    print(json.dumps({'ok':True,'status':'imported','app':'optimizer-v2',
                      'primary':'gostos.781751.xyz:18445','backup':'gosto.781751.xyz:18444',
                      'unchanged':True}))


if __name__ == '__main__':
    # Failures only reach the system journal as the generic event in adminctl.
    main()

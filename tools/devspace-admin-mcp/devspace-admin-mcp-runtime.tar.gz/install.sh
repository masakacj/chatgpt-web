#!/usr/bin/env bash
# DevSpace Admin MCP overlay; pinned online source, constrained commands, audited.
# Does NOT bypass ChatGPT platform security checks. Does NOT open a network listener.
set -Eeuo pipefail
umask 022

MODE="${1:-install}"
case "$MODE" in install|status|uninstall) ;; *) echo 'Usage: install.sh [install|status|uninstall]' >&2; exit 2;; esac

SERVER='/usr/lib/node_modules/@waishnav/devspace/dist/server.js'
PACKAGE='/usr/lib/node_modules/@waishnav/devspace/package.json'
TARGET='/opt/devspace-admin-mcp'
CONF='/etc/devspace-admin-mcp'
BROKER='/usr/local/sbin/devspace-adminctl'
BACKUP='/var/backups/devspace-admin-mcp/server.js.original'
SUDOERS='/etc/sudoers.d/devspace-admin-mcp'
SOURCE_BASE='https://raw.githubusercontent.com/masakacj/chatgpt-web/feature/mcp-admin-broker-20261117/tools/devspace-admin-mcp/src'
MARKER_IMPORT='import { registerAdminMcpTools } from "/opt/devspace-admin-mcp/register.mjs";'
MARKER_CALL='    registerAdminMcpTools(server);'

if [[ "$MODE" == 'status' ]]; then
  if [[ -f "$SERVER" ]] && grep -Fq "$MARKER_CALL" "$SERVER"; then
    echo 'DevSpace admin MCP: installed'
  else
    echo 'DevSpace admin MCP: not installed'
  fi
  systemctl is-active devspace.service 2>/dev/null || true
  if [[ $EUID -eq 0 && -x "$BROKER" ]]; then "$BROKER" list '{}' || true; fi
  exit 0
fi

if [[ $EUID -ne 0 ]]; then echo 'Use sudo bash install.sh' >&2; exit 1; fi
if [[ "$MODE" == 'uninstall' ]]; then
  if [[ -f "$SERVER" ]] && grep -Fq "$MARKER_CALL" "$SERVER"; then
    [[ -f "$BACKUP" ]] || { echo 'Original DevSpace server backup missing; refusing automatic removal' >&2; exit 1; }
    node --check "$BACKUP"
    install -o root -g root -m 0644 "$BACKUP" "$SERVER"
    node --check "$SERVER"
  fi
  rm -f "$SUDOERS"
  systemctl restart devspace.service
  systemctl is-active --quiet devspace.service
  echo 'DevSpace admin MCP overlay removed. Private registry and backups intentionally preserved.'
  exit 0
fi

command -v curl >/dev/null && command -v sha256sum >/dev/null && command -v python3 >/dev/null \
  && command -v node >/dev/null && command -v visudo >/dev/null || { echo 'Missing dependency' >&2; exit 2; }
[[ -f "$SERVER" && -f "$PACKAGE" ]] || { echo 'Existing DevSpace package not found' >&2; exit 2; }
[[ -f /etc/systemd/system/devspace.service ]] || { echo 'DevSpace systemd service not found' >&2; exit 2; }
node -e 'const p=require(process.argv[1]);if(p.name!=="@waishnav/devspace"||p.version!=="1.0.8")process.exit(2)' "$PACKAGE" \
  || { echo 'Unknown DevSpace package version. Review integration before installing.' >&2; exit 2; }
if ! grep -Fq "$MARKER_CALL" "$SERVER"; then
  [[ $(grep -Fc 'import express from "express";' "$SERVER") == 1 ]] \
    && [[ $(grep -Fc '    registerAppResource(server, "DevSpace Diff Card"' "$SERVER") == 1 ]] \
    || { echo 'Unexpected upstream DevSpace server layout, refusing patch' >&2; exit 2; }
fi

TMP="$(mktemp -d /tmp/devspace-admin-mcp.XXXXXXXX)"
cleanup() { rm -rf -- "$TMP"; }
trap cleanup EXIT

# Exact content hash pins: if the branch contents change, installation fails closed.
fetch_checked() {
  local relative="$1" expected="$2"
  local dest="$TMP/$(basename "$relative")"
  if [[ -n "${DEVSPACE_ADMIN_SOURCE_DIR:-}" && -f "${DEVSPACE_ADMIN_SOURCE_DIR}/${relative}" ]]; then
    install -m 0644 "${DEVSPACE_ADMIN_SOURCE_DIR}/${relative}" "$dest"
  else
    curl --fail --location --silent --show-error --retry 2 --max-time 30 \
      "$SOURCE_BASE/$relative" --output "$dest"
  fi
  printf '%s  %s\n' "$expected" "$dest" | sha256sum --check --status \
    || { echo "Source integrity mismatch: $relative" >&2; exit 3; }
}

# Values are generated from the reviewed public source files at publication.
fetch_checked 'handler.mjs' '289c00087d00a54d8d1dad61efcc1d9b717218898f351724c90dee1897bd225f'
fetch_checked 'adminctl.py' '0f8f38c187cca2eb2139667dbb76890dcf982b45c513707475048aedde14e8ee'
fetch_checked 'jobs/optimizer-v2-import.py' 'eb69f008215c71b0c9c2e7c7a79bac6a06ef8280eb74d62c814cc7cd7585dde5'

node --check "$TMP/handler.mjs"
python3 - "$TMP/adminctl.py" "$TMP/optimizer-v2-import.py" <<'PY'
import ast,sys
for name in sys.argv[1:]:
    ast.parse(open(name,encoding='utf-8').read(),filename=name)
print('Reviewed source syntax: OK')
PY

install -d -o root -g root -m 0755 "$TARGET" "$TARGET/jobs" "$CONF" /var/backups/devspace-admin-mcp
install -o root -g root -m 0644 "$TMP/handler.mjs" "$TARGET/register.mjs"
install -o root -g root -m 0755 "$TMP/adminctl.py" "$BROKER"
install -o root -g root -m 0755 "$TMP/optimizer-v2-import.py" "$TARGET/jobs/optimizer-v2-import.py"

if [[ ! -e "$CONF/profiles.json" ]]; then
  cat > "$TMP/profiles.json" <<EOF_PROFILE
{
  "schema": 1,
  "services": {
    "devspace": {"unit":"devspace.service", "actions":["status"]},
    "personal-config": {"unit":"personal-config.service", "actions":["status","start","restart","stop"]},
    "ipa-signer": {"unit":"ipa-signer.service", "actions":["status","start","restart"]},
    "ipa-signer-tunnel": {"unit":"ipa-signer-tunnel.service", "actions":["status","start","restart"]},
    "laocai-v3": {"unit":"laocai-v3.service", "actions":["status","start","restart","stop"]},
    "douyin-api": {"unit":"douyin-api.service", "actions":["status","start","restart"]},
    "douyin-resolver": {"unit":"douyin-resolver.service", "actions":["status","start","restart"]},
    "packing-web": {"unit":"packing-web-137.service", "actions":["status","start","restart"]},
    "packing-motion": {"unit":"packing-motion-137.service", "actions":["status","start","restart"]}
  },
  "deployments": {
    "optimizer-v2-import": {
      "sha256":"eb69f008215c71b0c9c2e7c7a79bac6a06ef8280eb74d62c814cc7cd7585dde5",
      "timeoutSeconds":45
    }
  }
}
EOF_PROFILE
  install -o root -g root -m 0644 "$TMP/profiles.json" "$CONF/profiles.json"
else
  [[ $(stat -c '%u' "$CONF/profiles.json") == 0 ]] \
    && [[ $(stat -c '%a' "$CONF/profiles.json") == 644 ]] \
    || { echo 'Existing registry permissions unexpected: refuse overwrite' >&2; exit 2; }
fi

# A narrow sudoers entry: never add generic NOPASSWD ALL.
printf '%s\n' 'devspace ALL=(root) NOPASSWD: /usr/local/sbin/devspace-adminctl' > "$TMP/sudoers"
chmod 0440 "$TMP/sudoers"
visudo -cf "$TMP/sudoers" >/dev/null
install -o root -g root -m 0440 "$TMP/sudoers" "$SUDOERS"

# Minimal, reversible overlay into the existing authenticated MCP endpoint.
PATCHED_THIS_RUN=0
rollback() {
  echo 'Installation failed; preserving the pre-install DevSpace server.' >&2
  if [[ "$PATCHED_THIS_RUN" == 1 && -f "$BACKUP" ]]; then
    install -o root -g root -m 0644 "$BACKUP" "$SERVER"
    systemctl restart devspace.service || true
  fi
}
trap rollback ERR
if ! grep -Fq "$MARKER_CALL" "$SERVER"; then
  if [[ ! -e "$BACKUP" ]]; then
    install -o root -g root -m 0644 "$SERVER" "$BACKUP"
  else
    echo 'Existing admin overlay backup found with unpatched live DevSpace: abort to avoid overwriting previous backup' >&2
    exit 3
  fi
  PATCHED_THIS_RUN=1
  python3 - "$SERVER" <<'PY'
from pathlib import Path
import sys
file=Path(sys.argv[1]); text=file.read_text()
a='import express from "express";'
b='    registerAppResource(server, "DevSpace Diff Card"'
assert text.count(a)==1 and text.count(b)==1
text=text.replace(a,'import { registerAdminMcpTools } from "/opt/devspace-admin-mcp/register.mjs";\n'+a,1)
text=text.replace(b,'    registerAdminMcpTools(server);\n'+b,1)
file.write_text(text)
PY
fi

node --check "$SERVER"
python3 - "$CONF/profiles.json" "$TARGET/jobs/optimizer-v2-import.py" <<'PY'
import hashlib,json,sys
cfg=json.load(open(sys.argv[1]))
assert cfg['schema']==1
assert cfg['deployments']['optimizer-v2-import']['sha256']==hashlib.sha256(open(sys.argv[2],'rb').read()).hexdigest()
print('Root-owned deployment registry: OK')
PY
systemctl restart devspace.service
sleep 2
systemctl is-active --quiet devspace.service
/usr/bin/sudo -u devspace -H /usr/bin/sudo -n "$BROKER" list '{}' > "$TMP/verify.json"
python3 - "$TMP/verify.json" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]))
assert r.get('ok') and 'optimizer-v2-import' in r.get('deployments',[]) and 'personal-config' in r.get('services',{})
print('DevSpace admin broker: installed, root-scoped tools registered; private data not exposed.')
PY
trap - ERR
printf '\nSUCCESS: Restarted existing DevSpace MCP with 4 admin tools.\n'
printf 'Existing OAuth endpoint is reused; no new network listener.\n'
printf 'Reconnect the mcpdebian connector to refresh its tool catalog.\n'
printf 'No deployment recipe was executed during installation.\n'
